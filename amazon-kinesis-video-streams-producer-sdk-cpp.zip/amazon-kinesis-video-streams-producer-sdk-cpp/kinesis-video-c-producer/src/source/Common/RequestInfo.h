/*******************************************
Request Info internal header
*******************************************/
#ifndef __KINESIS_VIDEO_REQUEST_INFO_INCLUDE_I__
#define __KINESIS_VIDEO_REQUEST_INFO_INCLUDE_I__

#pragma once

#ifdef  __cplusplus
extern "C" {
#endif

#ifdef  __cplusplus
}
#endif
#endif  /* __KINESIS_VIDEO_REQUEST_INFO_INCLUDE_I__ */
