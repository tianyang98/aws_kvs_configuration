
#ifndef __KINESIS_VIDEO_LWS_IOT_CREDENTIAL_PROVIDER_INCLUDE_I__
#define __KINESIS_VIDEO_LWS_IOT_CREDENTIAL_PROVIDER_INCLUDE_I__

#pragma once

#ifdef  __cplusplus
extern "C" {
#endif

STATUS blockingLwsCall(PRequestInfo, PCallInfo);

#ifdef  __cplusplus
}
#endif
#endif /* __KINESIS_VIDEO_LWS_IOT_CREDENTIAL_PROVIDER_INCLUDE_I__ */
