/*******************************************
Auth internal include file
*******************************************/
#ifndef __KINESIS_VIDEO_AUTH_INCLUDE_I__
#define __KINESIS_VIDEO_AUTH_INCLUDE_I__

#pragma once

#ifdef  __cplusplus
extern "C" {
#endif

////////////////////////////////////////////////////
// Function definitions
////////////////////////////////////////////////////

#ifdef  __cplusplus
}
#endif
#endif  /* __KINESIS_VIDEO_AUTH_INCLUDE_I__ */
